/* import React from 'react';
import { Alert } from 'react-bootstrap';

const AlertComponent = ({ show, message, onClose }) => {
  return (
    <Alert show={show} variant="success" onClose={onClose} dismissible>
      {message}
    </Alert>
  );
};

export default AlertComponent;
 */